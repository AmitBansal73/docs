# Application Portal Infrastructure Configurations

## How do you deploy the infrastructure in this repo?

### Pre-requisites

1. Install (https://terragrunt.gruntwork.io/docs/getting-started/install/)[Terragrunt]

### Deploying a single module

1. `cd` into a module's folder (e.g. `cd nonrev/qa/azure/wus/module-name`)
1. run `terragrunt plan` to see all the changes you're about to apply
1. If the plan looks good, run `terragrunt apply`

_NOTE: for the `plan`/`apply` steps, if you want to reference a module from your local machine, pass the `--terragrunt-source` CLI option_
```sh
terragrunt plan --terragrunt-source {local-path}/tf-modules//module-name
```

### Deploying all modules in an environment (e.g. `qa`, `staging`, etc)

1. `cd` into a environment folder (e.g. `cd nonrev/qa/azure/wus`)
1. run `terragrunt plan-all` to see all the changes you're about to apply
1. If the plan looks good, run `terragrunt apply-all`

_NOTE: for the `plan-all` `apply-all` steps, if you want to reference a module off your local machine, pass the `--terragrunt-source` CLI option_

```sh
terragrunt plan-all --terragrunt-source {local-path}/tf-modules//
```

## How is the code in this repo organized?

The code in this repo uses the following folder hierarchy:

```
root
  |- realm
    |- environment
      |- cloud
        |- region
          |- resource
```

Where:

* **Realm**: Within our network, there will be one or more realms, such a `nonrev`, `rev`, etc, to enable logical separation between non-public versus public facing environments.
* **Environment**: Within each realm, there will be one or more "environments", such as `qa`, `staging`, etc.  This environment could existing in one ore more public clouds AND/OR geographically in one ore more locations.
* **Cloud**: `azure`, `aws`, `colo`, etc
* **Region**: A region name within a specific cloud/data center.
* **Resource**: Within each region, we deploy all resources required by a specific product to operate, such as an block storage, databases, caching services, secrets management, app runtime, etc.  This could also include configuring pre-existing systems that the product leverages during runtime (e.g. api gateway mapping/routes, kubernetes cluster, etc).
