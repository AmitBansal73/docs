#!/bin/bash
# ASSUMES THE FOLLOWING ENV VARS ARE SET
# $SUBSCRIPTIONNAME
# $APPCONFIGNAME
# $KEYVAULTURI
# $AZURE_CLIENT_ID
# $AZURE_CLIENT_SECRET
# $AZURE_TENANT_ID


CreateUpdateAzureAppConfigValue() {
    local configName="${1}"
    local configValue="${2}"
    az appconfig kv set -n $APPCONFIGNAME --key ${configName} --value "${configValue}" --content-type "string" --yes
}

CreateAzureAppConfigKeyVaultRef() {
    local configName="${1}"
    local kvValueResponse="$(az appconfig kv list -n ${APPCONFIGNAME} --key ${configName})"
    local adjustedConfigName="$(echo ${configName} | sed 's/:/--/g' | sed 's/_/-/g')"
    if [ "$kvValueResponse" == "[]" ]
        then
            az appconfig kv set-keyvault -n ${APPCONFIGNAME} --key ${configName} --secret-identifier ${KEYVAULTURI}secrets/$(rawurlencode ${adjustedConfigName}) --yes
        else
            echo "Key vault reference for ${configName} already exists"
    fi
}

rawurlencode() {
  local string="${1}"
  local strlen=${#string}
  local encoded=""
  local pos c o

  for (( pos=0 ; pos<strlen ; pos++ )); do
     c=${string:$pos:1}
     case "$c" in
        [-_.~a-zA-Z0-9] ) o="${c}" ;;
        * )               printf -v o '%%%02x' "'$c"
     esac
     encoded+="${o}"
  done
  echo "${encoded}"    # You can either set a return variable (FASTER)
  REPLY="${encoded}"   #+or echo the result (EASIER)... or both... :p
}

az login --service-principal -u $AZURE_CLIENT_ID -p $AZURE_CLIENT_SECRET --tenant $AZURE_TENANT_ID
az account set --subscription $SUBSCRIPTIONNAME

#app config

#Shared
## Add shared keys here once consumer keys are added and we can identify them

###################
#app config for mostly mortgage
CreateUpdateAzureAppConfigValue "Logging:LogLevel:Default" "Warning"
CreateUpdateAzureAppConfigValue "AllowedHosts" "*"
CreateUpdateAzureAppConfigValue "RedisCache:DebugLogging" "false"
CreateUpdateAzureAppConfigValue "AppSettings:LPQ_WEBSITE" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "AppSettings:LQB_WEBSITE" $APMORTGAGE_URL
CreateUpdateAzureAppConfigValue "AppSettings:AWS.FromDomains" ""
CreateUpdateAzureAppConfigValue "AppSettings:smtpSendFrom" "donotreply@meridianlink.com"
CreateUpdateAzureAppConfigValue "AppSettings:ML.SmtpHost" "smtp.meridianlink.com"
CreateUpdateAzureAppConfigValue "AppSettings:StandardLoanCacheTimeMinutes" "5"
CreateUpdateAzureAppConfigValue "AppSettings:LandingPage.HostUrl" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "AppSettings:LandingPage.LandingPage.ExpiredMinutes" "5"
CreateUpdateAzureAppConfigValue "AppSettings:environment" "STAGE"
#CreateUpdateAzureAppConfigValue "AppSettings:webpackPort" "8087"
CreateUpdateAzureAppConfigValue "AppSettings:LQBDocumentFolderConsumerRoleTypeNumber" "4"
#see comment in consumer section for ip detail
CreateUpdateAzureAppConfigValue "AppSettings:LQBTokenServiceIPs" "::1; 127.0.0.1; 10.0.0.0/8; 10.62.88.0/21; 12.106.86.0/24; 20.184.246.0/24"
CreateUpdateAzureAppConfigValue "AppSettings:LQBGetLoanConsumersServiceIPs" "::1; 127.0.0.1; 10.0.0.0/8; 10.62.88.0/21; 12.106.86.0/24; 20.184.246.0/24"
CreateUpdateAzureAppConfigValue "AppSettings:LQBInvalidateConfigCacheServiceIPs" "::1; 127.0.0.1; 10.0.0.0/8; 10.62.88.0/21; 12.106.86.0/24; 20.184.246.0/24"
CreateUpdateAzureAppConfigValue "ApplicationInsights:Encoding" "UTF8"
#Periodic Checker Configs
CreateUpdateAzureAppConfigValue "LQBLoanStatusCheck:TimeDelayBetweenRuns" "01:00:00"
CreateUpdateAzureAppConfigValue "LQBLoanStatusCheck:RunThreads" "1"
#--
CreateUpdateAzureAppConfigValue "InstaTouchAPISetting:baseUrl" "https://api.uat.equifax.com/"
CreateUpdateAzureAppConfigValue "InstaTouchAPISetting:oauthGrantType" "client_credentials"
CreateUpdateAzureAppConfigValue "InstaTouchAPISetting:oauthScope" "https://api.equifax.com/business/instatouch-identity"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateUpdateAzureAppConfigValue "InstaTouchAPISettingDemo:baseUrl" "https://api.uat.equifax.com/"
CreateUpdateAzureAppConfigValue "InstaTouchAPISettingDemo:oauthGrantType" "client_credentials"
CreateUpdateAzureAppConfigValue "InstaTouchAPISettingDemo:oauthScope" "https://api.equifax.com/business/instatouch-identity"

CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:0" "https://achieve.creditapi.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:1" "https://credit.advcredit.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:2" "https://advantagecreditbureau.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:3" "https://advantageplus.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:4" "https://arc.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:5" "https://beta.mortgagecreditlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:6" "https://birchwood.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:7" "https://cbfbusinesssolutions.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:8" "https://login.ncacredit.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:9" "https://certifiedcredit.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:10" "https://cic.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:11" "https://cis.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:12" "https://alliance.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:13" "https://credit.ciscocredit.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:14" "https://calcoast.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:15" "https://cocc.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:16" "https://cbs.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:17" "https://creditlink.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:18" "https://credit.creditplus.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:19" "https://crs.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:20" "https://credit.credittechnologies.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:21" "https://ctinetwork.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:22" "https://decisionapp.creditapi.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:23" "https://credit.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:24" "https://demo.mortgagecreditlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:25" "https://sir.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:26" "https://fedcomp.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:27" "https://iscsite.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:28" "https://credit.kewaneecreditbureau.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:29" "https://lqb.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:30" "https://mcb.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:31" "https://mcbsav.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:32" "https://premium.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:33" "https://cdc.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:34" "https://order.professionalcreditservices.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:35" "https://credit.sarmamortgage.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:36" "https://svc1stinfo.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:37" "https://credit.settlementone.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:38" "https://sos.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:39" "https://taz.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:40" "https://ncs.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:41" "https://unitedoneresources.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:42" "https://ucs.meridianlink.com"


#app config for mostly consumer
#These will overwrite values in web.config. Notice: These keys MUST also be declared in web.config
#Consumer
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:BuildVersion" "7"
#Inbound(AZ appGateWay AP&LQB) 52.159.160.192
#Outbound(Az Firewall/FP) 20.184.246.208/28
#ISE/logic app 10.62.130.100
# 12.106.86.0/24 on-premise external IP(system sees this when user is on  VPN for rev)
# 172.30.35.0/24 on-premise external IP(system sees this when user is on  VPN for non-rev)

# 10.62.120.0/21 AKS REV
# 20.184.246.224/28 outbound rev, for simplicity use 20.184.246.0/24

# 10.62.88.0/21 AKS non-REV
# 20.184.246.200/29 outbound non-revrev, for simplicity use 20.184.246.0/24

# 10.62.52.0/21 AKS chaos

# 10.62.130.192/27,10.62.130.96/27, 10.62.130.160/27,10.62.130.128/27(rev ISE) for simplicity use 10.62.130.0/24

# 10.62.101.32/27,10.62.10-1.0/27, 10.62.101.64/27,10.62.101.96/27(non-rev ISE) for simplicity use 10.62.101.0/24

# 10.62.160.192/27,10.62.160.160/27, 10.62.160.96/27,10.62.160.128/27(chaos ISE) for simplicity use 10.62.160.0/24
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:INTERNAL_IPS_ADD" "127.0.0.1, 10.11.0.0, 10.110.0.0, 10.111.0.0, 10.60.0.0, 10.62.0.0,11.12.0.0, 12.106.86.0, 20.184.246.0, 40.78.0.0, 40.80.0.0, 104.42.0.0, 172.30.0.0, 208.81.0.0, 209.232.0.0"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:INTERNAL_IP_SUBNETS" "127.0.0.1, 11.12.13.0/24, 10.60.28.0/24, 10.60.29.0/24, 10.60.13.0/24, 10.11.33.0/24, 10.11.13.0/24, 10.111.25.0/24, 11.12.14.0/24, 172.30.26.0/24, 172.30.28.0/24, 172.30.29.0/24, 172.30.32.0/24, 172.30.33.0/24, 172.30.34.0/24, 172.30.35.0/24, 172.30.36.0/24, 172.30.37.0/24, 172.30.38.0/24, 10.62.88.0/21, 10.62.152.0/21, 10.62.120.0/21, 20.184.246.224/28"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:INTERNAL_ISE_SUBNETS" "104.42.38.252,40.78.3.206,10.62.101.96/27,10.62.101.0/24,10.62.130.0/24"

CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:UserActivationTokenExpireAfter" "7"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:LoginFailedCountExceed" "5"
#ENVIRONMENT is used to determine url encryption, bundle, apm publishing enable/disable. possible values:DEV/STAGE/TEST/LIVE
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:ENVIRONMENT" "STAGE"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:UseSourceMap" "N"
#LPQ_WEBSITE may only be used for logging purpose
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:LPQ_WEBSITE" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:CrossDomainServicesUrl" "https://mlapp.loanspq.com/crossdomainservices/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:TempPdfFilesCleanerPath" "d:\Websites\mlapp.loanspq.com\TempPdfFilesCleaner\bin\debug"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:LQB_WEBSITE" $APMORTGAGE_URL
#These values are the same as default value.  They are not needed but will leave them here for now.
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_LOGO_CONTAINER" "logos"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_AVATAR_CONTAINER" "avatars"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_FOOTER_IMAGES_CONTAINER" "customfooter"
#CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_CONFIG_CONTAINER" "config"
#CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_APP_SERVICE_DOMAINS" "lpqsite01.azurewebsites.net,lpqsite02.azurewesites.net"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:VirusScanBaseServiceUrl" "https://beta.loanspq.com, https://demo.loanspq.com, https://cs.loanspq.com"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:WALKME_SNIPPET_SRC" "https://cdn.walkme.com/users/d3026c8a9081474897e50fa9e0230bd5/test/walkme_d3026c8a9081474897e50fa9e0230bd5_https.js"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:BaseSubmitUrls" "https://beta.loanspq.com, https://beta.consumer.meridianlink.com, https://cs.loanspq.com, https://cs.consumer.meridianlink.com, https://demo.loanspq.com, https://demo.consumer.meridianlink.com, https://secure.loanspq.com, https://secure.consumer.meridianlink.com, https://apply-sta.golden1.com, https://hs.consumer.meridianlink.com"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:plaid_api_url" "https://sandbox.plaid.com/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:plaid_client_name" "MeridianLink"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:plaid_link_language" "en"
#Feature Flags
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.showText" "false"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.SaveAndFinishLater" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.VLSaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.HESaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.HEAdditionalFieldsToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.NewURLADeclarationFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.PLSaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.DASaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BLDASaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BLSaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.NewExternalTransferWorkflowFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.APMConfigurePortalIDTypes" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.PopIoScriptConfigurationFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.NewSameDayMicroDepositWorkflowFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.HappyOrNotScriptConfigurationFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BusinessLoanSSOToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.MortgageCustomQuestionFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BusinessDepositAccountSsoToggle" "True"

CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:RedisDebugLogging" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:RedisLogLevelExpirationMinutes" "30"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:CacheExpirationHours" "22"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:KeyVaultUri" "https://kv-wus-ap-chaos-perf.vault.azure.net/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:Encoding" "ASCII"

CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:SendGridUserId" "APAdmin@meridianlink.com"

#InstaTouchBaseUrl has different url for test and prod
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchBaseUrl" "https://api.uat.equifax.com/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthScope" "https://api.equifax.com/business/instatouch-identity"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthGrantType" "client_credentials"

#This for testting override when instatouch_api_environment_override="DEMO"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchBaseUrl_Demo" "https://api.uat.equifax.com/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthScope_Demo" "https://api.equifax.com/business/instatouch-identity"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthGrantType_Demo" "client_credentials"

#Services
#CreateUpdateAzureAppConfigValue "APConsumer:Services:MSMQ_LOG_QUEUE_PATH" "FormatName:DIRECT=OS:LoansPQLogMQ\PRIVATE$\log_repo"
#CreateUpdateAzureAppConfigValue "APConsumer:Services:LOG_CONFIG_FILE_WEB" "dev_web.config"

CreateUpdateAzureAppConfigValue "APConsumer:Services:LPQ_WEBSITE" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "APConsumer:Services:SMTP_SERVER" "10.11.17.233"
CreateUpdateAzureAppConfigValue "APConsumer:Services:ADMIN_EMAIL" "APAdmin@meridianlink.com"
CreateUpdateAzureAppConfigValue "APConsumer:Services:INTERNAL_IPS_ADD" "127.0.0.1, 11.12.13.0, 10.60.28.0, 10.60.29.0, 10.60.13.0, 10.11.0.0, 10.62.88.0, 10.111.25.0, 11.12.14.0, 20.184.246.0, 172.30.0.0"

#=========================================
#========Mortgage keyvault
CreateAzureAppConfigKeyVaultRef "RedisCache:CacheConnection"
CreateAzureAppConfigKeyVaultRef "ApplicationInsights:InstrumentationKey"
CreateAzureAppConfigKeyVaultRef "SendGrid:APIKey"
CreateAzureAppConfigKeyVaultRef "ConnectionStrings:DefaultConnection"
CreateAzureAppConfigKeyVaultRef "AppSettings:AP_PricingResultsProgramRateOption_Secret"
CreateAzureAppConfigKeyVaultRef "AppSettings:LQBTokenServiceUser"
CreateAzureAppConfigKeyVaultRef "AppSettings:LQBTokenServicePasswordHash"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISetting:consumerKey"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISetting:consumerSecret"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISetting:authorization"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISettingDemo:consumerKey"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISettingDemo:consumerSecret"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISettingDemo:authorization"

#============================================
#========Consumer Keyvault
CreateAzureAppConfigKeyVaultRef "APConsumer:ConnectionStrings:LPQMOBILE_CONNECTIONSTRING"
CreateAzureAppConfigKeyVaultRef "APConsumer:ConnectionStrings:LQB_WEBSITE_GETTOKEN_USER"
CreateAzureAppConfigKeyVaultRef "APConsumer:ConnectionStrings:LQB_WEBSITE_GETTOKEN_PASSWORD"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerSecret"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchAuthorizationV2"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerKey_Demo"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerSecret_Demo"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchAuthorizationV2_Demo"

CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:AZURE_MEDIA_ACCOUNT_NAME"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:AZURE_MEDIA_ACCOUNT_KEY"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:SendGridKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:FP_AppID"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:FP_AppKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:PROXY_AUTH_LOGIN"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:PROXY_AUTH_PASSWORD"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:LPQAPICertBase64"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:CertPassword"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstrumentationKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RijndaelManagedKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RijndaelManagedSalt"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RedisCache:CacheConnection"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RedisCache:SessionConnection"
#Service Keyvault
#APConsumer:Services:ConnectionStrings:LPQMOBILE_SERVICES_CONNECTIONSTRING" not need after 2021.12.3.0 update
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:ConnectionStrings:LPQMOBILE_SERVICES_CONNECTIONSTRING"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:ConnectionStrings:LPQMOBILE_CONNECTIONSTRING"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RedisCacheServices:CacheConnection"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RedisCacheServices:SessionConnection"
#NADA
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:NADA_LOGIN"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:NADA_PASSWORD"

#LPQ API for DecisionPro
#CreateAzureAppConfigKeyVaultRef "APConsumer:Services:LPQ_DP_USER"
#CreateAzureAppConfigKeyVaultRef "APConsumer:Services:LPQ_DP_PW"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RijndaelManagedKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RijndaelManagedSalt"
#Machine Keys
CreateAzureAppConfigKeyVaultRef "APConsumer:MACHINE_DECRYPTION_KEY"
CreateAzureAppConfigKeyVaultRef "APConsumer:MACHINE_VALIDATION_KEY"




