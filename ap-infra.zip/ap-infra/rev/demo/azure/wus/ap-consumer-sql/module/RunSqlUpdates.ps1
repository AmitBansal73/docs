param([String]$sqlScriptPath="Update.sql")
#CONNECTION_STRING
#TENANT_ID
#SP_ID
#SP_SECRET
#DB_NAME

function Run-SqlFile([string]$dbAccessToken, [string]$sqlScriptsPath, [string]$connectionString, [string]$dbFriendlyName) {
	
	Write-Host "Starting Run-Sql for $dbFriendlyName"
	if([string]::IsNullOrWhiteSpace($sqlScriptsPath)) {
		throw "Missing SQL Script File Path"
	}
	
	if([string]::IsNullOrWhiteSpace($connectionString)) {
		throw "Missing ConnectionString"
	}
	
	Write-Host "*****************************"
	Write-Host "Load SQL Scripts from $sqlScriptsPath"
	$sqlScriptFileLines = get-content $sqlScriptsPath

	$currentSqlScript = ''
	$sqlScripts = @();
	$sqlScriptFileLines | ForEach-Object {
	    if ($_.Trim() -match '^go$') {
		$sqlScripts += $currentSqlScript;
		$currentSqlScript = ''
	   }
	   else {
		$currentSqlScript += $_ + [Environment]::NewLine;
	   }
	   
	};

	$sqlScripts += $currentSqlScript;

	Write-Host "Create SQL Connection"
	$conn = New-Object System.Data.SqlClient.SQLConnection 
	$conn.ConnectionString = $connectionString
	$conn.AccessToken = $dbAccessToken
	
	$infoMessageHandler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {param($sender, $event) Write-Host "Info Message: " $event.Message };
	$conn.add_InfoMessage($infoMessageHandler);
	

	Write-Host "Connect to database and execute SQL script"

	$conn.Open()
	$sqlScripts | ForEach-Object {
		if(-not [string]::IsNullOrWhiteSpace($_)) {
			Write-Host $_ -ForeGroundColor 'DarkYellow'
			$command = New-Object -TypeName System.Data.SqlClient.SqlCommand($_, $conn)
			$command.CommandTimeout = 0
			$Result = $command.ExecuteNonQuery()
			Write-Host ("Result: " + $Result) -ForeGroundColor 'Blue'	
		}
		
	};
	$conn.Close() 

}

function Retrieve-AzureDBToken([string]$servicePrincipalId, [string]$servicePrincipalSecret, [string]$tenantID) {
	$resourceAppIdURI = 'https://database.windows.net/'
	$authority = "https://login.windows.net/$tenantID/oauth2/token"
	
	$tokenResponse = Invoke-RestMethod -Method Post -UseBasicParsing `
		-Uri $authority `
		-Body @{
			resource=$resourceAppIdURI
			client_id=$servicePrincipalId
			grant_type='client_credentials'
			client_secret=$servicePrincipalSecret
		} -ContentType 'application/x-www-form-urlencoded'

	if ($tokenResponse) {
		Write-Host "Retrieved Token: Access token type is " $tokenResponse.token_type ", expires " $tokenResponse.expires_on
		
		$Token = $tokenResponse.access_token
		return $Token
	}
	else{
		throw "Access Token Not retrieved"
	}
}

$Token = Retrieve-AzureDBToken $env:SP_ID $env:SP_SECRET $env:TENANT_ID
Run-SqlFile $Token $sqlScriptPath $env:CONNECTION_STRING $env:DB_NAME
