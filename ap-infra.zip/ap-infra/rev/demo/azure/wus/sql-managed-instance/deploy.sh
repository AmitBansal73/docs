# Set vars
RG='rg-wus-ap-rev-demo'

# Validate the template and parameters
az deployment group validate --resource-group $RG --template-file template.json --parameters @parameters.json administratorLoginPassword='areallytemppasswordthatwedontuse'

# Deploy the template with parameters
echo "Deploying the template ..."
az deployment group create --resource-group $RG --template-file template.json --parameters @parameters.json --no-wait # --rollback-on-error