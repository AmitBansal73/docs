#!/bin/bash
# ASSUMES THE FOLLOWING ENV VARS ARE SET
# $SUBSCRIPTIONNAME
# $APPCONFIGNAME
# $KEYVAULTURI
# $AZURE_CLIENT_ID
# $AZURE_CLIENT_SECRET
# $AZURE_TENANT_ID

CreateUpdateAzureAppConfigValue() {
    local configName="${1}"
    local configValue="${2}"
    az appconfig kv set -n $APPCONFIGNAME --key ${configName} --value "${configValue}" --content-type "string" --yes
}

CreateAzureAppConfigKeyVaultRef() {
    local configName="${1}"
    local kvValueResponse="$(az appconfig kv list -n ${APPCONFIGNAME} --key ${configName})"
    local adjustedConfigName="$(echo ${configName} | sed 's/:/--/g' | sed 's/_/-/g')"
    if [ "$kvValueResponse" == "[]" ]
        then
            az appconfig kv set-keyvault -n ${APPCONFIGNAME} --key ${configName} --secret-identifier ${KEYVAULTURI}secrets/$(rawurlencode ${adjustedConfigName}) --yes
        else
            echo "Key vault reference for ${configName} already exists"
    fi
}

rawurlencode() {
  local string="${1}"
  local strlen=${#string}
  local encoded=""
  local pos c o

  for (( pos=0 ; pos<strlen ; pos++ )); do
     c=${string:$pos:1}
     case "$c" in
        [-_.~a-zA-Z0-9] ) o="${c}" ;;
        * )               printf -v o '%%%02x' "'$c"
     esac
     encoded+="${o}"
  done
  echo "${encoded}"    # You can either set a return variable (FASTER)
  REPLY="${encoded}"   #+or echo the result (EASIER)... or both... :p
}

az login --service-principal -u $AZURE_CLIENT_ID -p $AZURE_CLIENT_SECRET --tenant $AZURE_TENANT_ID
az account set --subscription $SUBSCRIPTIONNAME


##==========================================
#=========Mortgage AppConfig
CreateUpdateAzureAppConfigValue "Logging:LogLevel:Default" "Warning"
CreateUpdateAzureAppConfigValue "AllowedHosts" "*"
CreateUpdateAzureAppConfigValue "RedisCache:DebugLogging" "false"
CreateUpdateAzureAppConfigValue "AppSettings:LPQ_WEBSITE" $APCONSUMER_URL
# https://app.lendingqb.com
CreateUpdateAzureAppConfigValue "AppSettings:LQB_WEBSITE" $APMORTGAGE_URL
CreateUpdateAzureAppConfigValue "AppSettings:AWS.FromDomains" ""
CreateUpdateAzureAppConfigValue "AppSettings:smtpSendFrom" "donotreply@meridianlink.com"
CreateUpdateAzureAppConfigValue "AppSettings:ML.SmtpHost" "smtp.meridianlink.com"
CreateUpdateAzureAppConfigValue "AppSettings:StandardLoanCacheTimeMinutes" "15"
CreateUpdateAzureAppConfigValue "AppSettings:LandingPage.HostUrl" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "AppSettings:LandingPage.LandingPage.ExpiredMinutes" "5"
CreateUpdateAzureAppConfigValue "AppSettings:environment" "PRODUCTION"
CreateUpdateAzureAppConfigValue "AppSettings:LQBDocumentFolderConsumerRoleTypeNumber" "4"

# see comments in consumer section for more detail
CreateUpdateAzureAppConfigValue "AppSettings:LQBTokenServiceIPs" "::1; 127.0.0.1; 10.0.0.0/8; 10.62.120.0/21; 12.106.86.0/24; 20.184.246.0/24"
CreateUpdateAzureAppConfigValue "AppSettings:LQBGetLoanConsumersServiceIPs" "::1; 127.0.0.1; 10.0.0.0/8; 10.62.120.0/21; 12.106.86.0/24; 20.184.246.0/24"
CreateUpdateAzureAppConfigValue "AppSettings:LQBInvalidateConfigCacheServiceIPs" "::1; 127.0.0.1; 10.0.0.0/8; 10.62.120.0/21; 12.106.86.0/24; 20.184.246.0/24"
CreateUpdateAzureAppConfigValue "ApplicationInsights:Encoding" "UTF8"

#Periodic Checker Configs
CreateUpdateAzureAppConfigValue "LQBLoanStatusCheck:TimeDelayBetweenRuns" "01:00:00"
CreateUpdateAzureAppConfigValue "LQBLoanStatusCheck:RunThreads" "1"
#--
CreateUpdateAzureAppConfigValue "InstaTouchAPISetting:baseUrl" "https://api.equifax.com/"
CreateUpdateAzureAppConfigValue "InstaTouchAPISetting:oauthGrantType" "client_credentials"
CreateUpdateAzureAppConfigValue "InstaTouchAPISetting:oauthScope" "https://api.equifax.com/business/instatouch-identity"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateUpdateAzureAppConfigValue "InstaTouchAPISettingDemo:baseUrl" "https://api.uat.equifax.com/"
CreateUpdateAzureAppConfigValue "InstaTouchAPISettingDemo:oauthGrantType" "client_credentials"
CreateUpdateAzureAppConfigValue "InstaTouchAPISettingDemo:oauthScope" "https://api.equifax.com/business/instatouch-identity"

CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:0" "https://achieve.creditapi.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:1" "https://credit.advcredit.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:2" "https://advantagecreditbureau.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:3" "https://advantageplus.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:4" "https://arc.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:5" "https://beta.mortgagecreditlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:6" "https://birchwood.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:7" "https://cbfbusinesssolutions.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:8" "https://login.ncacredit.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:9" "https://certifiedcredit.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:10" "https://cic.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:11" "https://cis.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:12" "https://alliance.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:13" "https://credit.ciscocredit.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:14" "https://calcoast.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:15" "https://cocc.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:16" "https://cbs.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:17" "https://creditlink.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:18" "https://credit.creditplus.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:19" "https://crs.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:20" "https://credit.credittechnologies.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:21" "https://ctinetwork.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:22" "https://decisionapp.creditapi.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:23" "https://credit.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:24" "https://demo.mortgagecreditlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:25" "https://sir.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:26" "https://fedcomp.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:27" "https://iscsite.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:28" "https://credit.kewaneecreditbureau.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:29" "https://lqb.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:30" "https://mcb.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:31" "https://mcbsav.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:32" "https://premium.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:33" "https://cdc.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:34" "https://order.professionalcreditservices.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:35" "https://credit.sarmamortgage.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:36" "https://svc1stinfo.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:37" "https://credit.settlementone.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:38" "https://sos.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:39" "https://taz.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:40" "https://ncs.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:41" "https://unitedoneresources.meridianlink.com"
CreateUpdateAzureAppConfigValue "SmartAPI:WhiteListedMclDomains:42" "https://ucs.meridianlink.com"

#feature flags
CreateUpdateAzureAppConfigValue "FeatureManagement:CombinedPrimaryWithJointFeatureToggle" "False"
CreateUpdateAzureAppConfigValue "FeatureManagement:ToggleMobileNumber" "False"

#=========================
#=== Mortgage Keyvault
CreateAzureAppConfigKeyVaultRef "ConnectionStrings:DefaultConnection"
CreateAzureAppConfigKeyVaultRef "AppSettings:AP_PricingResultsProgramRateOption_Secret"
CreateAzureAppConfigKeyVaultRef "AppSettings:LQBTokenServiceUser"
CreateAzureAppConfigKeyVaultRef "AppSettings:LQBTokenServicePasswordHash"

CreateAzureAppConfigKeyVaultRef "RedisCache:CacheConnection"
CreateAzureAppConfigKeyVaultRef "ApplicationInsights:InstrumentationKey"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISetting:consumerKey"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISetting:consumerSecret"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISetting:authorization"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISettingDemo:consumerKey"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISettingDemo:consumerSecret"
CreateAzureAppConfigKeyVaultRef "InstaTouchAPISettingDemo:authorization"
CreateAzureAppConfigKeyVaultRef "SendGrid:APIKey"


############################################
#==== Consumer AppConfig
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:BuildVersion" "7"

#VDI india:10.111.25.229, 10.111.25.230-->
#AP-T-WEBAP01: 10.11.13.190, 10.11.13.184 -->
#lqb support 10.60.0.0-->
#lpb support 172.30.26.0, 172.30.28.0, 172.30.29.0, 172.30.32.0, 172.30.33.0, 172.30.34.0, 172.30.35.0, 172.30.36.0, 172.30.37.0, 172.30.38.0, 172.30.39.0-->
#east coast 10.111.20.184(10.111.20.0), 208.81.32.0, 209.232.26.0-->
#control minify, url encryption, an IP restriciton -->
#APmortgage k8s vnet : 10.62.120.0, 10.62.4.0 -->
#Outbound(Az Firewall/FP) 20.184.246.208/28 (this is what system will see when mortage is on cloud)

# 12.106.86.0/24 on-premise external IP(system sees this when user is on  VPN for rev)

# 10.62.120.0/21 AKS REV
# 20.184.246.224/28 outbound rev, for simplicity use 20.184.246.0/24

# 10.62.88.0/21 AKS non-REV
# 20.184.246.200/29 outbound non-revrev, for simplicity use 20.184.246.0/24

# 10.62.52.0/21 AKS chaos

#ISE
# 10.62.130.192/27,10.62.130.96/27, 10.62.130.160/27,10.62.130.128/27(rev ISE) for simplicity use 10.62.130.0/24
# 10.62.101.32/27,10.62.10-1.0/27, 10.62.101.64/27,10.62.101.96/27(non-rev ISE) for simplicity use 10.62.101.0/24
# 10.62.160.192/27,10.62.160.160/27, 10.62.160.96/27,10.62.160.128/27(chaos ISE) for simplicity use 10.62.160.0/24
# HQ IPs 10.110.0.0, 136.244.0.0, 136.226.0.0, 165.225.0.0 
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:INTERNAL_IPS_ADD" "127.0.0.1, 10.11.0.0, 10.110.0.0, 10.111.0.0, 10.60.0.0, 10.62.0.0,11.12.0.0, 12.106.86.0, 20.184.246.0, 40.78.0.0, 40.80.0.0, 104.42.0.0, 136.244.0.0, 136.226.0.0, 165.225.0.0, 172.30.0.0, 208.81.0.0, 209.232.0.0"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:INTERNAL_IP_SUBNETS" "127.0.0.1, 11.12.13.0/24, 10.60.28.0/24, 10.60.29.0/24, 10.60.13.0/24, 10.62.130.0/24, 10.11.33.0/24, 10.11.13.0/24, 10.111.25.0/24, 11.12.14.0/24, 10.62.88.0/21, 10.62.152.0/21, 10.62.120.0/21, 12.106.86.0/24, 20.184.246.0/24, 172.30.26.0/24, 172.30.28.0/24, 172.30.29.0/24, 172.30.32.0/24, 172.30.33.0/24, 172.30.34.0/24, 172.30.35.0/24, 172.30.36.0/24, 172.30.37.0/24, 172.30.38.0/24"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:INTERNAL_ISE_SUBNETS" "104.42.38.252,40.78.3.206,10.62.101.96/27,10.62.101.64/27, 10.62.130.0/24, 12.106.86.0/24"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:UserActivationTokenExpireAfter" "7"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:LoginFailedCountExceed" "5"
#ENVIRONMENT is used to determine url encryption, bundle, apm publishing enable/disable. possible values:DEV/STAGE/TEST/LIVE
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:ENVIRONMENT" "LIVE"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:UseSourceMap" "N"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:LPQ_WEBSITE" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:CrossDomainServicesUrl" "https://mlapp.loanspq.com/crossdomainservices/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:TempPdfFilesCleanerPath" "d:\Websites\mlapp.loanspq.com\TempPdfFilesCleaner\bin\debug"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:LQB_WEBSITE" $APMORTGAGE_URL
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_LOGO_CONTAINER" "logos"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_AVATAR_CONTAINER" "avatars"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_FOOTER_IMAGES_CONTAINER" "customfooter"
#CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_CONFIG_CONTAINER" "config"
#CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:AZURE_APP_SERVICE_DOMAINS" "lpqsite01.azurewebsites.net,lpqsite02.azurewesites.net"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:VirusScanBaseServiceUrl" "https://es.consumer.meridianlink.com, https://ws.consumer.meridianlink.com, https://secure.consumer.meridianlink.com, https://cs.consumer.meridianlink.com"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:WALKME_SNIPPET_SRC" "https://cdn.walkme.com/users/d3026c8a9081474897e50fa9e0230bd5/walkme_d3026c8a9081474897e50fa9e0230bd5_https.js"
#BaseSubmitUrls has more urls here for testing purpose.
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:BaseSubmitUrls" "https://192.168.1.24, https://apply-sta.golden1.com, https://apply.soundcu.com, https://beta.loanspq.com, https://cs.loanspq.com, https://cs.consumer.meridianlink.com, https://demo.loanspq.com, https://fhb.loanspq.com, https://hs.loanspq.com, https://hs.consumer.meridianlink.com, https://live.consumer.meridianlink.com, https://loans.langleyfcu.org, https://loans.truliantfcu.org, https://mlink.ibmsecu.org, https://secure.loanspq.com, https://secure.consumer.meridianlink.com, https://ws.loanspq.com, https://ws.consumer.meridianlink.com, https://www-lc3csq.myappro.com, https://access.memberonefcu.com, https://accounts.fairwinds.org, https://aefcu.loanspq.com, https://apply.aacreditunion.org, https://apply.avadiancu.com, https://apply.calcoastcu.org, https://apply.empowerfcu.com, https://apply.golden1.com, https://apply.northislandcu.com, https://apply.pffcu.org, https://apply.redwoodcu.org, https://apply.selco.org, https://applynow.penair.org, https://coastal24.loanspq.com, https://coastal24.consumer.meridianlink.com,  https://epl.loanspq.com, https://epl.consumer.meridianlink.com,  https://es.loanspq.com, https://es.consumer.meridianlink.com, https://fastapp.kitsapcu.org, https://hs.loanspq.com, https://hs.consumer.meridianlink.com, https://hvfcu.loanspq.com, https://hvfcu.consumer.meridianlink.com, https://jha.loanspq.com, https://jha.consumer.meridianlink.com, https://join.bcu.org, https://loanspq.amhfcu.org, https://loanspq.mygenfcu.org, https://loanspq.srpfcu.org, https://mlink.ibmsecu.org, https://my.kinecta.org, https://nao.members1st.org, https://newaccounts.afcu.org, https://oregoncommunitycu.loanspq.com, https://secureapply.cacu.com, https://st.loanspq.com, https://st.consumer.meridianlink.com, https://webloan.additionfi.com, https://wingsfinancial.loanspq.com, https://www-lc3cst.myappro.com, https://webloantest.additionfi.com, https://meridianlink.dcunet.org, https://newaccounts.sdccu.com, https://ml.suncoastcreditunion.com, https://aa.loanspq.com, https://apply.californiacu.org, https://onpoint.loanspq.com, https://republicbank.loanspq.com, https://apply.summitcreditunion.com, https://jdcu.loanspq.com, https://myloan.navyarmyccu.com, https://loanpro.americafirst.com,    https://loanpro.americafirst.com, https://apply.wsecu.org, https://mlink.ithinkfi.org, https://loans.langleyfcu.org, https://ml.suncoastcreditunion.com, https://new-account.providentcu.org,   https://consumerloans.flagstar.com, https://websvc.flagstar.com, https://websvc.flagstar.com/loanspq, https://apply.ccu.com"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:plaid_api_url" "https://production.plaid.com/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:plaid_client_name" "MeridianLink"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:plaid_link_language" "en"
#Feature Flags
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.showText" "false"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.SaveAndFinishLater" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.VLSaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.HESaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.HEAdditionalFieldsToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.NewURLADeclarationFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.PLSaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.DASaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BLDASaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BLSaveAndFinishLaterFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.APMConfigurePortalIDTypes" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.NewExternalTransferWorkflowFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.PopIoScriptConfigurationFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.NewSameDayMicroDepositWorkflowFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.HappyOrNotScriptConfigurationFeatureToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BusinessDepositAccountSsoToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.BusinessLoanSSOToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.APMRateLimiterSettingUIToggle" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:FeatureToggle.EmailPhoneTableLenderSecurityToggle" "True"

CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:RedisDebugLogging" "True"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:RedisLogLevelExpirationMinutes" "30"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:CacheExpirationHours" "22"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:KeyVaultUri" "https://kv-wus-ap-rev-prod.vault.azure.net/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:Encoding" "ASCII"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:SendGridUserId" "APAdmin@meridianlink.com"
#InstaTouchBaseUrl has different url for test and prod
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchBaseUrl" "https://api.equifax.com/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthScope" "https://api.equifax.com/business/instatouch-identity"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthGrantType" "client_credentials"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchBaseUrl_Demo" "https://api.uat.equifax.com/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthScope_Demo" "https://api.equifax.com/business/instatouch-identity"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:InstaTouchOauthGrantType_Demo" "client_credentials"
#JDPower(NADA Vin lookup has different url for test and prod)
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:JDPowerBaseUrl" "https://cloud.jdpower.ai/data-api/valuationservices/valuation/"

#reCAPTCHA Enterprise AppSettings, keys are stored in Consumer keyvault
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:reCaptchaEnterpriseBaseUrl" "https://recaptchaenterprise.googleapis.com/v1beta1/"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:reCaptchaEnterpriseProjectID" "portal-prod-334707"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:reCaptchaEnterpriseKeyID" "898614bc7eb5b20d6b0459867f35b9d9e9c08a9e"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:reCaptchaEnterpriseServiceID"  "102343611417521005950"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:reCaptchaEnterpriseServiceEmail" "recaptcha-enterprise-agent-ser@portal-prod-334707.iam.gserviceaccount.com"
CreateUpdateAzureAppConfigValue "APConsumer:AppSettings:ApitureUrl" "https://fxws.fundsxpress.com/axbi-admin/dao"

#Services
CreateUpdateAzureAppConfigValue "APConsumer:Services:LPQ_WEBSITE" $APCONSUMER_URL
CreateUpdateAzureAppConfigValue "APConsumer:Services:INTERNAL_IPS_ADD" "127.0.0.1, 10.11.33.0, 10.11.13.0, 10.111.0.0, 10.60.13.0, 10.60.28.0, 10.60.29.0, 10.62.120.0, 10.62.4.0, 10.62.88.0, 10.62.152.0, 10.62.120.0, 10.62.130.0, 11.12.13.0, 11.12.14.0,172.30.26.0, 12.106.86.0, 20.184.246.0, 40.80.156.205,40.80.152.218,104.42.156.123,104.42.216.21,40.78.63.47,40.80.156.103,40.78.62.97,40.80.153.6, 172.30.26.0, 172.30.28.0, 172.30.29.0, 172.30.32.0, 172.30.33.0, 172.30.34.0, 172.30.35.0, 172.30.36.0, 172.30.37.0, 172.30.38.0, 172.30.39.0"

#======================
#=====  Consumer website Keyvault - should be sorted alphabetically
CreateAzureAppConfigKeyVaultRef "APConsumer:ConnectionStrings:LPQMOBILE_CONNECTIONSTRING"
CreateAzureAppConfigKeyVaultRef "APConsumer:ConnectionStrings:LQB_WEBSITE_GETTOKEN_USER"
CreateAzureAppConfigKeyVaultRef "APConsumer:ConnectionStrings:LQB_WEBSITE_GETTOKEN_PASSWORD"
#CUNAMutualAPI (Production credentials are used for all environement thus they are specified web.config  )
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerSecret"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchAuthorizationV2"
#This for testting override when instatouch_api_environment_override="DEMO"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerKey_Demo"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchConsumerSecret_Demo"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstaTouchAuthorizationV2_Demo"

#JDPower(NADA Vin lookup)
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:JDPowerAPIKey"

#reCAPTCHA Enterprise AppSettings
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:reCaptchaEnterpriseApiKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:reCaptchaEnterpriseSiteKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:reCaptchaEnterprisePrivateKey"

CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:AZURE_MEDIA_ACCOUNT_NAME"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:AZURE_MEDIA_ACCOUNT_KEY"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:SendGridKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:FP_AppID"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:FP_AppKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:LPQAPICertBase64"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:CertPassword"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:InstrumentationKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RijndaelManagedKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RijndaelManagedSalt"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RedisCache:CacheConnection"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:RedisCache:SessionConnection"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:URL_ENCRYPTION_KEY"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:ApitureCertPassword"
CreateAzureAppConfigKeyVaultRef "APConsumer:AppSettings:ApitureCertBase64"


##################################
#Service website Keyvault
#LPQMOBILE_SERVICES_CONNECTIONSTRING will not be needed after 2021.12.3.0 update
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:ConnectionStrings:LPQMOBILE_SERVICES_CONNECTIONSTRING"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RedisCacheServices:CacheConnection"

#LPQ API for DecisionPro
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:LPQ_DP_USER"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:LPQ_DP_PW"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RijndaelManagedKey"
CreateAzureAppConfigKeyVaultRef "APConsumer:Services:RijndaelManagedSalt"
#Machine Keys
CreateAzureAppConfigKeyVaultRef "APConsumer:MACHINE_DECRYPTION_KEY"
CreateAzureAppConfigKeyVaultRef "APConsumer:MACHINE_VALIDATION_KEY"